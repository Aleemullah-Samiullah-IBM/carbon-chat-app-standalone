# @agent-ui/common

Common shared UI components and utilities for Agent UI applications.

## Installation

To install the package from the Artifactory repository:

```bash
# Configure npm to use the Artifactory repository for @apic scope
npm config set @apic:registry https://na.artifactory.swg-devops.com/artifactory/api/npm/apic-prod-npm/

# Install the package
npm install @agent-ui/common
```

### For Monorepo Usage (web-sample, web-app, vscode-plugin)

The package is already linked within the monorepo. Just import it directly:

```typescript
import {APIProvider, Message, useMyContext} from '@agent-ui/common'
```

## Usage

### Basic Import (Recommended for External Apps)

Import '@agent-ui/common/style.css' to your main app file to ensure all common component styles are loaded

Import compiled components from the main entry point:

```typescript
import {
  APIProvider,
  ChatProvider,
  Message,
  LoadingMessage,
  PromptInput,
  useMyContext,
  useAPI,
} from '@agent-ui/common'
```

### Source Imports (For Monorepo Development)

For faster development within the monorepo, you can import directly from source:

```typescript
import {Message} from '@agent-ui/common/src/components/message/message'
import {useMyContext} from '@agent-ui/common/src/contexts/ChatContext'
```

## Available Exports

### Components

- `ApimEmptyState` – APIM empty state
- `ApimInstanceSelector` – APIM instance selector
- `Block` – Block component
- `DocumentationLink` – Documentation link component
- `ErrorNotification` – Error notification component
- `LearnMoreLink` – Learn more link component
- `LoadingMessage` – Loading state message
- `Message` – Main message component
- `PorgPicker` – PORG picker component
- `PorgPickerInModal` – PORG picker in modal
- `PorgPickerModal` – PORG picker modal
- `PromptInput` – Input component for prompts
- `ReadOnlySettingsPage` – Read-only settings page
- `RemoteDomRenderer` – Remote DOM renderer
- `SamplePrompts` – Sample prompts modal
- `Toolbar` – Toolbar component

### Contexts & Hooks

- `ChatProvider` - Chat context provider
- `useMyContext` - Hook to access chat context
- `useInput` - Hook for input management
- `ErrorProvider` - Error context provider
- `useError` - Hook to access error context
- `APIProvider` - API context provider
- `useAPI` - Hook to access API context

### Services

- `ApiService` - API service class
- HTTP utilities from `./services/http/http`
- API fetch utilities from `./services/http/apiFetch`

### Types

All TypeScript types are exported from `./types`:

- `Message` types
- `Command` types
- `Plan` types
- `Selection` types
- `FileData` types
- `User` types
- `ErrorRemediation` types
- `POrgName` types

### Utilities

- Helper functions from `./utilities/helpers`
- `createWelcomeMessage` - Create welcome message utility

### Constants

All constants exported from `./constants`

### Icons

All icons exported from `./icons/icons`

## Package Structure

```
@agent-ui/common/
├── dist/              # Compiled JavaScript and TypeScript declarations
│   ├── index.js       # Main entry point
│   ├── index.d.ts     # TypeScript declarations
│   └── ...            # Other compiled files
├── src/               # Source TypeScript files (available for monorepo)
│   ├── components/
│   ├── contexts/
│   ├── services/
│   ├── types/
│   └── utilities/
└── package.json
```

## Building the Package

To build the package:

```bash
cd packages/common
npm run build
```

To clean and rebuild:

```bash
npm run clean
npm run build
```

## Publishing

The package is configured to publish to the IBM Artifactory registry:

```bash
npm publish
```

The `prepublishOnly` script will automatically clean and build before publishing.

## Creating a Package Archive

To create a `.tgz` file for testing or distribution:

```bash
cd packages/common
npm pack
```

This creates `agent-ui-common-1.0.0.tgz` which can be installed locally:

```bash
npm install /path/to/agent-ui-common-1.0.0.tgz
```

## TypeScript Configuration

The package uses ESNext modules with the following key settings:

- **Module**: ESNext
- **Target**: ESNext
- **JSX**: react-jsx
- **Declaration**: true (generates .d.ts files)
- **Declaration Maps**: true (for better IDE support)

## Peer Dependencies

This package expects the following peer dependencies in your project:

- `react` ^18.0.0
- `react-dom` ^18.0.0

## Dependencies

The package includes:

- `@carbon/react` - Carbon Design System components
- `@carbon/icons-react` - Carbon icons
- `axios` - HTTP client
- `react-markdown` - Markdown rendering
- And other utilities (see package.json)

## Troubleshooting

### Import Issues

If you encounter import errors like "Module not found":

1. **Ensure the package is built**: Run `npm run build` in `packages/common`
2. **Check your import path**: Use `@agent-ui/common` not `@agent-ui/common/dist`
3. **Verify package.json exports**: The main export is `./dist/index.js`

### TypeScript Errors

If TypeScript can't find type definitions:

1. Ensure `dist/index.d.ts` exists (run `npm run build`)
2. Check your `tsconfig.json` includes proper module resolution
3. Verify the package is properly installed in `node_modules`

### Monorepo Development

For faster development in the monorepo, you can:

1. Use source imports: `@agent-ui/common/src/*`
2. This avoids rebuilding after every change
3. The TypeScript compiler will handle the source files directly

## Example Usage

```typescript
import React from 'react'
import {
  APIProvider,
  ChatProvider,
  ErrorProvider,
  Message,
  PromptInput,
  useMyContext,
} from '@agent-ui/common'

import '@agent-ui/common/style.css'

function ChatApp() {
  return (
    <ErrorProvider>
      <APIProvider>
        <ChatProvider>
          <ChatInterface />
        </ChatProvider>
      </APIProvider>
    </ErrorProvider>
  )
}

function ChatInterface() {
  const {messages, sendMessage} = useMyContext()

  return (
    <div>
      {messages.map(msg => (
        <Message
          key={msg.id}
          message={msg}
        />
      ))}
      <PromptInput onSend={sendMessage} />
    </div>
  )
}

export default ChatApp
```

## License

See the main repository LICENSE file.

## Contributing

See CONTRIBUTING.md in the root of the repository.
